declare module 'mastodon-api';
